# =========================================== #

#!/system/bin/sh
# === RESTORE PERFORMANCE MODE DEFAULT ===

# Power settings (balik normal)
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd power set-mode 1  # balanced

# Thermal restore
cmd thermalservice override-status reset

# Hapus konfigurasi power_check custom
settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global power_check_max_cpu_4

# HWUI dan EGL default
setprop debug.hwui.target_power_time_percent 0
setprop debug.hwui.trace_gpu_resources true
setprop debug.egl.force_msaa true
setprop debug.hwui.use_hint_manager 0
setprop debug.hwui.disable_vsync false
setprop debug.hwui.disable_scissor_opt false
setprop debug.performance.tuning 0
setprop debug.composition.type gpu
setprop debug.hwui.renderer opengl
setprop debug.renderengine.backend skiagl
setprop debug.cpurend.vsync true