#!/system/bin/sh
# Source Code NovaAethernium DoxXel Extention
# Tanks To Lykafka For Source setprop
# This File function for Opltimalization GPU to be more stable when used for playing games

#  Render tweak, which functions to optimize rendering while playing games.
setprop debug.sf.enable_transaction_tracing 0
setprop debug.tracing.battery_status 3
setprop debug.skia.enable_reuse_scratch_textures 0
setprop debug.renderengine.blur_algorithm false
setprop debug.renderengine.capture_skia_ms 0
setprop debug.renderengine.capture_filename ""
setprop debug.renderengine.graphite false
setprop debug.renderengine.restore_blur_step false
setprop debug.renderengine.graphite_preview_optin false
setprop debug.renderengine.skia_atrace_enabled false
setprop debug.renderengine.skia_tracing_enabled false
setprop debug.renderengine.skia_use_perfetto_track_events false
setprop persist.sys.renderengine.maxLuminance ""

setprop debug.sf.hwc_service_name drmfb
setprop debug.hwc.compose_level 0
setprop debug.hwc.force_gpu 0
setprop debug.hwc.asyncdisetprop 0
setprop debug.hwc.otf 0
setprop debug.hwc.bq_count 3
setprop debug.hwc.disabletonemapping false
setprop debug.egl.force_msaa false
setprop debug.hwui.disable_vsync false
setprop debug.hwui.use_buffer_age 0
setprop debug.sf.disable_backpressure 0

setprop debug.drm.mode.auto 0
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.disable_client_composition_cache 0
setprop debug.sf.disable_hwc_overlays 0
setprop debug.sf.disable_hwc 0
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.gpu_comp_tiling 0
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.hwc.min.duration 06666666
setprop debug.sf.high_fps.hwc.min.duration 00000000
setprop persist.sys.hwcomposer.force_gpu 0
setprop persist.sys.sf.enable_hwc_vds 0
setprop persist.sys.rendercomposer.enable false

cmd deviceidle disable
cmd power set-fixed-performance-mode-enabled false
cmd disetproplay set-user-disabled-hdr-types 0 2 3 4
setprop debug.performance.profile 0 
setprop debug.perf.tuning 0
setprop debug.composition.type gpu
settings put global low_power 0
settings put global low_power_sticky 0
settings put global enable_gpu_debug_layers 0
setprop debug.hwui.trace_gpu_resources false
settings put global settings_enable_monitor_phantom_procs false

am start -a AxManager.TOAST -e text "NovaAethernium Tweak Activated"