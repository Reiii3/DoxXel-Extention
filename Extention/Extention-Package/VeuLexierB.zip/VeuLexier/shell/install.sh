#!/system/bin/sh

mv ${0%/*}/system/lex.sh /data/local/tmp
chmod 777 /data/local/tmp/lex.sh

SCRIPT_PATH="/data/local/tmp/lex.sh"

# ==== CEK FILE SCRIPT ADA ====
if [ ! -f "$SCRIPT_PATH" ]; then
    am start -a AxManager.TOAST -e text "Error: lex.sh tidak ditemukan"
    exit 1
fi

# ==== CEK LOKASI LOG AMAN ====
LOG_PATH="/dev/null"

# Kalau /system read-only → pindah ke /data/local/tmp
if ! touch "$LOG_PATH" 2>/dev/null; then
    LOG_PATH="/data/local/tmp/lex.log"
fi

# ==== CEK SUDAH BERJALAN BELUM ====
PID_EXIST=$(pgrep -f "$SCRIPT_PATH")
if [ -n "$PID_EXIST" ]; then
    am start -a AxManager.TOAST -e text "Smart Cache Cleaner sudah aktif"
    exit 0
fi

# ==== START BACKGROUND PROCESS ====
nohup "$SCRIPT_PATH" > "$LOG_PATH" 2>&1 &

sleep 0.5

# ==== CEK BERHASIL JALAN ====
NEW_PID=$(pgrep -f "$SCRIPT_PATH")

if [ -n "$NEW_PID" ]; then
    am start -a AxManager.TOAST -e text "Smart Cache Cleaner Activated"
else
    am start -a AxManager.TOAST -e text "Gagal Mengaktifkan Smart Cache Cleaner"
fi