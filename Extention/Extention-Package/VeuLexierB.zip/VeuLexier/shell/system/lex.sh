#!/system/bin/sh
notif_run="running"
current_time=10m
# =========================================
#   AETERNUM AI ENGINE — ULTRA MODE (SAFE)
# =========================================

engine() {
  pkg="com.android.systemui"
  
  # ================= HEAVY APPS =================
  
  # ===================================================
  #              SYSTEMUI RAM SCANNER
  # ===================================================
  get_mem_sysui() {
      info=$(dumpsys meminfo $pkg | sed -n '/App Summary/,/Objects/p' | sed 's/://')
  
      get() { echo "$info" | grep -m1 "$1" | awk '{print $3}'; }
  
      java=$(get "Java Heap")
      native=$(get "Native Heap")
      code=$(get "Code")
      stack=$(get "Stack")
      graphics=$(get "Graphics")
      private=$(get "Private Other")
      system=$(get "System")
  
      for v in java native code stack graphics private system; do
          eval "[ -z \${$v} ] && $v=0"
      done
  
      total=$((java + native + code + stack + graphics + private + system))
      echo "$total"
  }
  
  toMB() { echo $(( $1 / 1024 )); }
  
  
  # ===================================================
  #              USER APP RAM SCANNER
  # ===================================================
  get_app_ram() {
      pkgname="$1"
      mem=$(dumpsys meminfo "$pkgname" 2>/dev/null | grep "TOTAL PSS" | awk '{print $3}')
      echo ${mem:-0}
  }
  
  USER_PKGS=$(pm list packages --user 0 | sed 's/package://')
  
  
  # ===================================================
  #                GMS RAM SCANNER
  # ===================================================
  get_gms_ram() {
      val=$(dumpsys meminfo com.google.android.gms 2>/dev/null | grep "TOTAL PSS" | awk '{print $3}')
      echo ${val:-0}
  }
  
  
  # ===================================================
  #                NOTIFICATION ON START
  # ===================================================
  if [[ $notif_run == "running" ]]; then
      cmd notification post -S bigtext -t 'VeuLexier Engine' \
      "noxg_engine_mode" \
      "VeuLexier Engine —  Smart Cache Cleaner Running..." >/dev/null 2>&1
      am start -a AxManager.TOAST -e text "CLEANING CACHE"  >/dev/null 2>&1
      notif_run="stopped"
  fi
  
  
  # ===================================================
  #           RAM SCAN — BEFORE CLEANING
  # ===================================================
  echo ""
  echo "🔍 Mengambil RAM SystemUI (SEBELUM)..."
  before_sysui=$(get_mem_sysui)
  echo "SystemUI Sebelum : $(toMB $before_sysui) MB"
  
  echo ""
  echo "🔍 Menghitung RAM seluruh aplikasi user (SEBELUM)..."
  total_before_apps=0
  for p in $USER_PKGS; do
      val=$(get_app_ram "$p")
      total_before_apps=$((total_before_apps + val))
  done
  before_apps_MB=$((total_before_apps / 1024))
  echo "RAM User Apps Sebelum : ${before_apps_MB} MB"
  
  echo ""
  echo "🔍 Mengambil RAM GMS (SEBELUM)..."
  before_gms=$(get_gms_ram)
  before_gms_MB=$((before_gms / 1024))
  echo "RAM GMS Sebelum : ${before_gms_MB} MB"
  
  
  # ===================================================
  #               OPTIMIZATION STEPS
  # ===================================================
  echo ""
  echo "⚠ Killing cached apps..."
  cmd activity kill-all
  sleep 1
  
  # ======= DISABLE DROPBOX ========
  for a in $(cmd settings list secure | grep dropbox | cut -f1 -d=); do
      cmd settings delete secure "$a"
  done
  cmd dropbox restore-defaults
  cmd dropbox set-rate-limit "$(echo 2^62 | bc)"
  cmd settings put global dropbox_max_files 0
  
  # ======= DISABLE LOGGING ========
  for a in $(cmd package list packages --user 0 | grep -v ia.mo | cut -f2 -d:); do
      cmd package log-visibility --disable "$a"
  done
  
  for b in $(cmd settings list global | cut -f1 -d= | grep logging); do
      cmd settings put global "$b" 0
  done
  
  for c in $(cmd settings list secure | cut -f1 -d= | grep logging); do
      cmd settings put secure "$c" 0
  done
  
  for d in $(cmd settings list system | cut -f1 -d= | grep logging); do
      cmd settings put system "$d" 0
  done
  
  # ======= DISABLE TRACING ========
  atrace --async_stop >/dev/null
  cmd activity trace-ipc stop
  cmd window tracing stop
  echo 0 > /sys/kernel/tracing/tracing_on 2>/dev/null
  
  
  # ===================================================
  #            CLEAR CACHE (ALL)
  # ===================================================
  echo ""
  echo "🧹 Membersihkan cache semua aplikasi user..."
  
  for p in $USER_PKGS; do
      rm -rf /data/data/$p/cache/* 2>/dev/null
      rm -rf /data/data/$p/code_cache/* 2>/dev/null
  done
  
  # user_de dirs
  find /data/user_de/*/*/cache/* -delete 2>/dev/null
  find /data/user_de/*/*/code_cache/* -delete 2>/dev/null
  
  # sdcard dirs
  find /sdcard/Android/data/*/cache/* -delete 2>/dev/null
  
  # extra wipe
  rm -rf /sdcard/DCIM/.thumbnails/* 2>/dev/null
  rm -f /data/misc/logd/* 2>/dev/null
  
  # ================= GMS CACHE CLEANER ==================
  echo "🧹 Membersihkan cache Google Mobile Services..."
  rm -rf /data/data/com.google.android.gms/cache/* 2>/dev/null
  rm -rf /data/data/com.google.android.gms/code_cache/* 2>/dev/null
  rm -rf /data/user_de/0/com.google.android.gms/cache/* 2>/dev/null
  rm -rf /data/user_de/0/com.google.android.gms/code_cache/* 2>/dev/null
  
  pm trim-caches 1024G 2>/dev/null >&1
  sleep 1
  
  # ========= RUNNING CMD CLEANER ============
      cmd safety_center clear-data
      cmd stats clear-puller-cache
      cmd stats config remove 0
      cmd telecom cleanup-orphan-phone-accounts
      cmd telecom cleanup-stuck-calls
      cmd time_detector clear_network_time
      cmd time_detector clear_system_clock_network_time
  
  # ===================================================
  #           RAM SCAN — AFTER CLEANING
  # ===================================================
  echo ""
  echo "🔍 Mengambil RAM SystemUI (SESUDAH)..."
  after_sysui=$(get_mem_sysui)
  echo "SystemUI Sesudah : $(toMB $after_sysui) MB"
  
  echo ""
  echo "🔍 Menghitung RAM seluruh aplikasi user (SESUDAH)..."
  total_after_apps=0
  for p in $USER_PKGS; do
      val=$(get_app_ram "$p")
      total_after_apps=$((total_after_apps + val))
  done
  after_apps_MB=$((total_after_apps / 1024))
  echo "RAM User Apps Sesudah : ${after_apps_MB} MB"
  
  echo ""
  echo "🔍 Mengambil RAM GMS (SESUDAH)..."
  after_gms=$(get_gms_ram)
  after_gms_MB=$((after_gms / 1024))
  echo "RAM GMS Sesudah : ${after_gms_MB} MB"
  
  
  # ===================================================
  #                    FINAL REPORT
  # ===================================================
  echo ""
  echo "=============================================="
  echo "       VEULECIER ULTRA ENGINE — REPORT"
  echo "=============================================="
  echo "SystemUI Sebelum : $(toMB $before_sysui) MB"
  echo "SystemUI Sesudah : $(toMB $after_sysui) MB"
  echo "Pengurangan UI   : $(( (before_sysui/1024) - (after_sysui/1024) )) MB"
  echo ""
  echo "User Apps Sebelum : ${before_apps_MB} MB"
  echo "User Apps Sesudah : ${after_apps_MB} MB"
  echo "Pengurangan Apps   : $((before_apps_MB - after_apps_MB)) MB"
  echo ""
  echo "GMS Sebelum : ${before_gms_MB} MB"
  echo "GMS Sesudah : ${after_gms_MB} MB"
  echo "Pengurangan GMS : $((before_gms_MB - after_gms_MB)) MB"
  echo "=============================================="
}

while true; do
    engine
    sleep $current_time
  
done