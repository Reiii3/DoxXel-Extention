# =========================================== #
# Source Code V1.0.0                          #
# =========================================== #
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
cmd thermalservice override-status 0
settings put global power_check_max_cpu_1 110
settings put global power_check_max_cpu_2 110
settings put global power_check_max_cpu_3 80
settings put global power_check_max_cpu_4 80
setprop debug.hwui.target_power_time_percent 100
setprop debug.hwui.trace_gpu_resources false
setprop debug.egl.force_msaa false
setprop debug.hwui.use_hint_manager 1
setprop debug.hwui.disable_vsync true
setprop debug.hwui.disable_scissor_opt true

setprop debug.performance.tuning 1
setprop debug.composition.type dyn
setprop debug.hwui.renderer vulkan
setprop debug.renderengine.backend skiavkthreaded